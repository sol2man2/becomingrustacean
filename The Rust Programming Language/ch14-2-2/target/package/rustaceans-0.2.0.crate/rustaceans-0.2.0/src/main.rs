fn main() {
    println!("Hello, world!");
}

// Adding Metadata to a New Crate
// Publishing to Crates.io
// Publishing a New Version of an Existing Crate
// Removing Versions from Crates.io with cargo yank
